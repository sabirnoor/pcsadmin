<?php $__env->startSection('content'); ?>

<div class="main-content-inner">
    <div class="breadcrumbs ace-save-state" id="breadcrumbs">
        <ul class="breadcrumb">
            <li>
                <i class="ace-icon fa fa-home home-icon"></i>
                <a href="<?php echo e(url('/')); ?>">Dashboard</a>
            </li>
            <li class="active">Academics</li>
        </ul><!-- /.breadcrumb -->


    </div>

    <div class="page-content">


        <div class="row">
            <div class="col-xs-12">
                <?php if(session('msgerror')): ?>
                <div class="alert alert-danger light no-margin">
                        <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                        <i class="icon-cross2"></i> <?php echo e(session('msgerror')); ?>

                </div>
                <hr>
                <?php endif; ?>
                <?php if(session('msgsuccess')): ?>
                <div class="alert alert-success light no-margin">
                        <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                        <i class="icon-check_circle"></i> <?php echo e(session('msgsuccess')); ?>

                </div>
                <hr>
                <?php endif; ?>
                
                <form class="form-horizontal" method="post" role="form" action="<?php echo e(url('academics')); ?>">
                    <?php echo e(csrf_field()); ?>

                    <input type="hidden" name="page_name" value="academics">
                    <div class="form-group">
                        <label for="form-field-1"> Academics </label>
                        <textarea name="contents" id="editor1" rows="10" cols="80">
                            <?php if(isset($details->contents)): ?>
                           <?php echo e($details->contents); ?>

                           <?php endif; ?>
                       </textarea>

                    </div>
<!--                    <div class="form-group">
                        <label class="col-sm-2 control-label no-padding-right" for="form-field-1"> Text Field </label>

                        <div class="col-sm-9">
                            <input type="text" id="form-field-1" placeholder="Username" class="col-xs-10 col-sm-5" />
                        </div>
                    </div>-->
                    <div class="space-4"></div>
                    <div class="clearfix form-actions">
                        <div class="col-md-offset-3 col-md-9">
                            <button class="btn btn-info" type="submit">
                                    <i class="ace-icon fa fa-check bigger-110"></i>
                                    Submit
                            </button>

                            &nbsp; &nbsp; &nbsp;
                            <button class="btn" type="reset">
                                    <i class="ace-icon fa fa-undo bigger-110"></i>
                                    Reset
                            </button>
                        </div>
                    </div>
                </form>

               

                <div class="hr hr32 hr-dotted"></div>



                <!-- PAGE CONTENT ENDS -->
            </div><!-- /.col -->
        </div><!-- /.row -->
    </div><!-- /.page-content -->
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>